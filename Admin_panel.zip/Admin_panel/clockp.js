// Analog Clock - Parameters Head Script
// You may change the parameters here to set up your clock
// refer to  http://javascript.about.com/library/blclock1.htm
// for a description of the parameters
var clocksize=50;
var colnumbers='ffffff';
var colseconds='fff';
var colminutes='fff';
var colhours='fff';
var numstyle = 2;
var font_family = 'helvetica,arial,sans-serif';
var localZone = 1;
var mytimezone = 0;
var dst = 0;
var city = '';
var country = '';
var fix = 1;
var xpos=0;
var ypos=0;

// code to adjust for daylight saving time if applicable (localzone = 0)

// code to handle clock positioning (fix = 0)
                  