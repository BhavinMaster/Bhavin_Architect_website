<?php

$conn=mysql_connect('localhost','root','');

mysql_select_db('project2') or die('database can not connect');

?>