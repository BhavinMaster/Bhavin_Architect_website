<html>
<head>
<title>Admin Panel</title>
</head>
<body>
<?php include 'connect.php'; ?>
<?php include 'functions.php'; ?>
<?php include 'title_bar.php'; ?>
</body>
</html>